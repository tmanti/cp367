#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

    int n1, n2, sum;
   printf("Input the first integer:");
   scanf("%i", &n1);
   printf("Input the second integer:");
   scanf("%i", &n2);
   printf("Sum of the above two integers = %i\n", n1+n2);

    return 0;
} 
